# Web scraping and sentiment analysis
This was my first scraping and sentiment analysis project, done for the university course "Text mining & sentiment analysis".

The object of analysis are the Amazon reviews of the book "Pre-Suasion" by Robert Cialdini, very important for me because it was my first reading on social psychology. 
